/*
 Navicat Premium Data Transfer

 Source Server         : newroot
 Source Server Type    : MySQL
 Source Server Version : 50648
 Source Host           : localhost:3306
 Source Schema         : uims

 Target Server Type    : MySQL
 Target Server Version : 50648
 File Encoding         : 65001

 Date: 03/07/2021 17:34:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`course_id`, `id`) USING BTREE,
  INDEX `course_id`(`course_id`) USING BTREE,
  INDEX `id`(`id`) USING BTREE,
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES (400, '数据结构', 300);
INSERT INTO `course` VALUES (401, '操作系统', 302);
INSERT INTO `course` VALUES (402, 'Java', 301);

-- ----------------------------
-- Table structure for take
-- ----------------------------
DROP TABLE IF EXISTS `take`;
CREATE TABLE `take`  (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grade` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`, `course_id`) USING BTREE,
  INDEX `course_id`(`course_id`) USING BTREE,
  CONSTRAINT `take_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of take
-- ----------------------------
INSERT INTO `take` VALUES (200, 'cui', 400, '数据结构', 90);
INSERT INTO `take` VALUES (200, '200', 401, '操作系统', 88);
INSERT INTO `take` VALUES (200, 'cui', 402, 'Java', 86);
INSERT INTO `take` VALUES (201, 'deng', 401, '操作系统', 90);
INSERT INTO `take` VALUES (201, 'deng', 402, 'Java', 91);
INSERT INTO `take` VALUES (302, 'yan', 400, '数据结构', 89);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `level` int(11) NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`, `password`, `username`) USING BTREE,
  INDEX `id`(`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('admin', 'admin', 100, 'admin', 1, '13349325008', '北京大学');
INSERT INTO `user` VALUES ('cui', 'cui', 200, 'cui', 2, '14756653232', '清华大学');
INSERT INTO `user` VALUES ('deng', 'deng', 201, 'deng', 2, '14357575757', '北京大学');
INSERT INTO `user` VALUES ('jiang', 'jiang', 300, 'jiang', 3, '13256566464', '吉林大学');
INSERT INTO `user` VALUES ('qin', 'qin', 301, '琴', 3, '13456788765', '东北大学');
INSERT INTO `user` VALUES ('yan', 'yan', 302, 'yan', 3, '18778787878', '延边大学');

SET FOREIGN_KEY_CHECKS = 1;
